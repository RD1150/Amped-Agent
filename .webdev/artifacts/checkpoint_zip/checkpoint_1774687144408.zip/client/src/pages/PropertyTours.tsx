import { useState, useEffect, useRef, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Upload, Video, Loader2, Download, Trash2, Play, Edit, RefreshCw, PartyPopper, Copy, Check, X, Repeat2, UserCircle2, AlertCircle, ChevronDown, ChevronUp } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Progress } from "@/components/ui/progress";
import { ImageCropModal } from "@/components/ImageCropModal";
import { compressVideo } from "@/lib/videoCompression";
import { useLocation } from "wouter";
import { MusicLibrary } from "@/components/MusicLibrary";
import YouTubeSEOPanel from "@/components/YouTubeSEOPanel";

// Smart video thumbnail that preloads before allowing play
function VideoThumbnail({ src, thumbnailUrl, address }: { src: string; thumbnailUrl?: string; address: string }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlayClick = () => {
    const video = videoRef.current;
    if (!video) return;
    if (!isReady) {
      setIsLoading(true);
      video.preload = "auto";
      video.load();
      video.oncanplaythrough = () => {
        setIsLoading(false);
        setIsReady(true);
        video.play();
        setIsPlaying(true);
      };
    } else {
      if (isPlaying) {
        video.pause();
        setIsPlaying(false);
      } else {
        video.play();
        setIsPlaying(true);
      }
    }
  };

  return (
    <div className="w-full h-full relative group cursor-pointer" onClick={handlePlayClick}>
      <video
        ref={videoRef}
        src={src}
        className="w-full h-full object-cover"
        playsInline
        preload="none"
        poster={thumbnailUrl}
        onEnded={() => setIsPlaying(false)}
      />
      {!isPlaying && (
        <div className="absolute inset-0 bg-black/30 group-hover:bg-black/50 transition-colors flex items-center justify-center">
          {isLoading ? (
            <Loader2 className="h-6 w-6 text-white animate-spin" />
          ) : (
            <Play className="h-6 w-6 text-white" />
          )}
        </div>
      )}
    </div>
  );
}

export default function PropertyTours() {
  const utils = trpc.useUtils();

  // Form state
  const [address, setAddress] = useState("");
  const [price, setPrice] = useState("");
  const [beds, setBeds] = useState("");
  const [baths, setBaths] = useState("");
  const [sqft, setSqft] = useState("");
  const [propertyType, setPropertyType] = useState("");
  const [description, setDescription] = useState("");
  const [template, setTemplate] = useState<"modern" | "luxury" | "cozy">("modern");
  const [duration, setDuration] = useState(30);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [uploadedImageUrls, setUploadedImageUrls] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [generatingTourId, setGeneratingTourId] = useState<number | null>(null);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generationStatus, setGenerationStatus] = useState("");
  const [includeBranding, setIncludeBranding] = useState(true);
  const [aspectRatio, setAspectRatio] = useState<"16:9" | "9:16" | "1:1">("16:9");
  const [musicTrack, setMusicTrack] = useState<string | undefined>(undefined);
  const [musicTrackUrl, setMusicTrackUrl] = useState<string | undefined>(undefined);
  const [musicVolume, setMusicVolume] = useState(50);
  const [cardTemplate, setCardTemplate] = useState<"modern" | "luxury" | "bold" | "classic" | "contemporary">("modern");
  const [includeIntroVideo, setIncludeIntroVideo] = useState(false);

  const [enableVoiceover, setEnableVoiceover] = useState(false);
  const [voiceId, setVoiceId] = useState("21m00Tcm4TlvDq8ikWAM"); // Rachel - professional female
  const [voiceoverStyle, setVoiceoverStyle] = useState<"professional" | "warm" | "luxury" | "casual">("professional");
  const [previewingVoiceId, setPreviewingVoiceId] = useState<string | null>(null);
  const [previewAudioUrl, setPreviewAudioUrl] = useState<string | null>(null);
  const [showScriptEditor, setShowScriptEditor] = useState(false);
  const [generatedScript, setGeneratedScript] = useState("");
  const [customScript, setCustomScript] = useState("");
  const [perPhotoMovements, setPerPhotoMovements] = useState<string[]>([]);
  const [movementSpeed, setMovementSpeed] = useState<"slow" | "fast">("fast");
  const [videoMode, setVideoMode] = useState<"standard" | "ai-enhanced">("standard");

  const [cropModalOpen, setCropModalOpen] = useState(false);
  const [cropImageIndex, setCropImageIndex] = useState<number | null>(null);
  // Avatar headshot for intro video overlay
  const [useProfileAvatar, setUseProfileAvatar] = useState<boolean | null>(null); // null = not yet decided
  const [customAvatarFile, setCustomAvatarFile] = useState<File | null>(null);
  const [customAvatarPreview, setCustomAvatarPreview] = useState<string>("");
  const [avatarCropImageUrl, setAvatarCropImageUrl] = useState<string>("");
  const [showAvatarCropModal, setShowAvatarCropModal] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [previewVideoUrl, setPreviewVideoUrl] = useState<string | null>(null);

  // Video-ready celebration modal
  const [readyVideoUrl, setReadyVideoUrl] = useState<string | null>(null);
  const [readyVideoAddress, setReadyVideoAddress] = useState<string>("");
  const [copiedLink, setCopiedLink] = useState(false);

  const [previewingScript, setPreviewingScript] = useState(false);
  const [expandedErrorTourId, setExpandedErrorTourId] = useState<number | null>(null);
  const [scriptAudioUrl, setScriptAudioUrl] = useState<string | null>(null);
  const [scriptAudioPlaying, setScriptAudioPlaying] = useState(false);

  // Queries
  const { data: tours, isLoading: toursLoading } = trpc.propertyTours.list.useQuery();
  const { data: creditCost } = trpc.credits.calculateCost.useQuery({ videoMode, enableVoiceover });
  const { data: balance } = trpc.credits.getBalance.useQuery();
  const { data: dailyUsage } = trpc.rateLimit.getDailyUsage.useQuery();
  const { data: voicePref } = trpc.auth.getVoicePreference.useQuery();
  const { data: currentUser } = trpc.auth.me.useQuery();
  const { data: personaData } = trpc.persona.get.useQuery();
  const updateAvatarImageMutation = trpc.auth.updateAvatarImage.useMutation();

  // Auto-populate voice preferences from saved profile settings
  // If agent has a cloned voice, prefer it over the generic preference
  useEffect(() => {
    if (personaData && (personaData as any).elevenlabsVoiceId) {
      setVoiceId((personaData as any).elevenlabsVoiceId);
    } else if (voicePref) {
      setVoiceId(voicePref.voiceId);
      setVoiceoverStyle(voicePref.voiceoverStyle);
    }
  }, [voicePref, personaData]);

  // Mutations
  const uploadImages = trpc.propertyTours.uploadImages.useMutation();
  const createTour = trpc.propertyTours.create.useMutation();
  const generateVideo = trpc.propertyTours.generateVideo.useMutation();
  const deleteTour = trpc.propertyTours.delete.useMutation();
  const retryVideo = trpc.propertyTours.retryVideo.useMutation();
  const fetchPropertyData = trpc.propertyTours.fetchPropertyData.useMutation();
  const generateVoiceoverScript = trpc.propertyTours.generateVoiceoverScript.useMutation();
  const previewVoice = trpc.propertyTours.previewVoice.useMutation();

  // Handle file selection
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const newTotal = selectedFiles.length + files.length;
    
    // Enforce 10-file maximum
    if (newTotal > 10) {
      toast.error("Maximum 10 files allowed. For best results, select 5-10 of your best photos/videos showing key features.");
      return;
    }
    
    // Validate video files
    for (const file of files) {
      if (file.type.startsWith('video/')) {
        // Check file size (100MB limit)
        const sizeMB = file.size / (1024 * 1024);
        if (sizeMB > 100) {
          toast.error(`Video "${file.name}" is too large (${sizeMB.toFixed(1)}MB). Maximum size is 100MB.`);
          return;
        }
        
        // Check video duration (2 minutes = 120 seconds limit)
        try {
          const duration = await getVideoDuration(file);
          if (duration > 120) {
            toast.error(`Video "${file.name}" is too long (${Math.floor(duration)}s). Maximum duration is 2 minutes (120s).`);
            return;
          }
        } catch (error) {
          console.error('Error checking video duration:', error);
          // Continue anyway if duration check fails
        }
      }
    }
    
    setSelectedFiles((prev) => [...prev, ...files]);
  };
  
  // Helper function to get video duration
  const getVideoDuration = (file: File): Promise<number> => {
    return new Promise((resolve, reject) => {
      const video = document.createElement('video');
      video.preload = 'metadata';
      
      video.onloadedmetadata = () => {
        window.URL.revokeObjectURL(video.src);
        resolve(video.duration);
      };
      
      video.onerror = () => {
        reject(new Error('Failed to load video metadata'));
      };
      
      video.src = URL.createObjectURL(file);
    });
  };

  // Handle file upload to S3 using direct endpoint
  // Compress image on client side to bypass gateway limits
  const compressImage = async (file: File): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const reader = new FileReader();
      
      reader.onload = (e) => {
        img.src = e.target?.result as string;
      };
      
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        
        // Resize to max 1920px on longest side
        const maxDimension = 1920;
        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = (height / width) * maxDimension;
            width = maxDimension;
          } else {
            width = (width / height) * maxDimension;
            height = maxDimension;
          }
        }
        
        canvas.width = width;
        canvas.height = height;
        
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Failed to get canvas context'));
          return;
        }
        
        ctx.drawImage(img, 0, 0, width, height);
        
        // Compress to JPEG with 0.7 quality (aggressive compression)
        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(blob);
            } else {
              reject(new Error('Failed to compress image'));
            }
          },
          'image/jpeg',
          0.7
        );
      };
      
      img.onerror = () => reject(new Error('Failed to load image'));
      reader.onerror = () => reject(new Error('Failed to read file'));
      
      reader.readAsDataURL(file);
    });
  };

  const handleUploadImages = async () => {
    if (selectedFiles.length === 0) {
      toast.error("Please select at least one property image");
      return;
    }

    setIsUploading(true);
    
    try {
      const uploadedUrls: string[] = [];
      
      // Upload files ONE AT A TIME (compress images, upload videos directly)
      for (let i = 0; i < selectedFiles.length; i++) {
        const file = selectedFiles[i];
        let fileToUpload: File;
        
        // Check if file is a video
        if (file.type.startsWith('video/')) {
          // Videos: Compress if over 50MB
          const fileSizeMB = file.size / (1024 * 1024);
          if (fileSizeMB > 50) {
            toast.info(`Compressing video ${i + 1}/${selectedFiles.length}: ${file.name} (${fileSizeMB.toFixed(1)}MB)`);
            fileToUpload = await compressVideo(file, {
              maxSizeMB: 50,
              targetSizeMB: 35,
              onProgress: (progress) => {
                if (progress % 20 === 0) { // Update every 20%
                  toast.info(`Compressing: ${Math.round(progress)}%`);
                }
              }
            });
            const compressedSizeMB = fileToUpload.size / (1024 * 1024);
            toast.success(`Video compressed: ${fileSizeMB.toFixed(1)}MB → ${compressedSizeMB.toFixed(1)}MB`);
          } else {
            toast.info(`Uploading video ${i + 1}/${selectedFiles.length}: ${file.name}`);
            fileToUpload = file;
          }
        } else {
          // Images: Compress before upload
          toast.info(`Compressing ${i + 1}/${selectedFiles.length}: ${file.name}`);
          const compressedBlob = await compressImage(file);
          fileToUpload = new File([compressedBlob], file.name, { type: 'image/jpeg' });
          toast.info(`Uploading ${i + 1}/${selectedFiles.length}: ${file.name}`);
        }
        
        // Create FormData with file (compressed image or raw video)
        const formData = new FormData();
        formData.append("images", fileToUpload);

        // Upload via direct endpoint
        const response = await fetch("/api/upload-images", {
          method: "POST",
          body: formData,
        });

        if (!response.ok) {
          throw new Error(`Upload failed: ${response.statusText}`);
        }

        const data = await response.json();
        uploadedUrls.push(...data.urls);
        
        toast.success(`✅ Uploaded ${i + 1}/${selectedFiles.length}`);
      }
      
      setUploadedImageUrls(uploadedUrls);
      setSelectedFiles([]);

      toast.success(`✅ All ${uploadedUrls.length} images uploaded successfully!`);
    } catch (error) {
      console.error("Upload error:", error);
      toast.error(error instanceof Error ? error.message : "Failed to upload images");
    } finally {
      setIsUploading(false);
    }
  };

  // Preview a voice using ElevenLabs
  const handleVoicePreview = async (vId: string) => {
    if (previewingVoiceId === vId) return; // already loading
    setPreviewingVoiceId(vId);
    setPreviewAudioUrl(null);
    try {
      const result = await previewVoice.mutateAsync({ voiceId: vId });
      setPreviewAudioUrl(result.url);
      // Auto-play via a hidden audio element
      const audio = new Audio(result.url);
      audio.play().catch(() => {});
    } catch {
      toast.error("Could not load voice preview. Please try again.");
    } finally {
      setPreviewingVoiceId(null);
    }
  };

  // Generate voiceover script using tRPC (server-side LLM)
  const generateScript = useCallback(async (): Promise<string> => {
    try {
      const result = await generateVoiceoverScript.mutateAsync({
        address,
        price: price || undefined,
        beds: beds ? parseFloat(beds) : undefined,
        baths: baths ? parseFloat(baths) : undefined,
        sqft: sqft ? parseInt(sqft) : undefined,
        propertyType: propertyType || undefined,
        description: description || undefined,
        duration,
        style: voiceoverStyle,
      });
      return result.script;
    } catch (error) {
      console.error('Failed to generate script:', error);
      toast.error("Failed to generate voiceover script. You can write your own below.");
      return "Welcome to this stunning property. Let me take you on a tour of this beautiful home, featuring exceptional design and premium finishes throughout. Contact me today to schedule your private showing.";
    }
  }, [address, price, beds, baths, sqft, propertyType, description, duration, voiceoverStyle, generateVoiceoverScript]);

  // Handle tour creation and video generation
  const handleCreateTour = async () => {
    if (!address) {
      toast.error("Please enter the property address");
      return;
    }

    // Validate manually uploaded photos
    if (uploadedImageUrls.length === 0) {
      toast.error("Please upload at least one property image");
      return;
    }

    // If voiceover is enabled and script not reviewed yet, show script editor
    if (enableVoiceover && !showScriptEditor && !customScript) {
      // Generate script first using tRPC
      toast.loading("Generating voiceover script...", { id: "script-gen" });
      const script = await generateScript();
      toast.dismiss("script-gen");
      setGeneratedScript(script);
      setCustomScript(script);
      setShowScriptEditor(true);
      return;
    }

    try {
      // Create tour
      const tour = await createTour.mutateAsync({
        address,
        price: price || undefined,
        beds: beds ? parseInt(beds) : undefined,
        baths: baths ? parseFloat(baths) : undefined,
        sqft: sqft ? parseInt(sqft) : undefined,
        propertyType: propertyType || undefined,
        description: description || undefined,
        imageUrls: uploadedImageUrls,
        template,
        duration,
        includeBranding,
        aspectRatio,
        musicTrack,
        cardTemplate,
        includeIntroVideo,
        videoMode,
        enableVoiceover,
        voiceId: enableVoiceover ? voiceId : undefined,
        voiceoverScript: customScript || undefined,
        perPhotoMovements: perPhotoMovements.length > 0 
          ? perPhotoMovements.map(m => m || "auto")  // Replace null/undefined with "auto"
          : undefined,
        movementSpeed,
      });

      // Set generating state
      setGeneratingTourId(tour.id);
      setGenerationProgress(10);
      setGenerationStatus("Queuing video generation...");

      // Generate video — returns immediately (fire-and-forget background job)
      await generateVideo.mutateAsync({ tourId: tour.id });

      setGenerationProgress(15);
      setGenerationStatus("Video queued. Starting generation...");

      let pollCount = 0;
      // AI Walkthrough: Kling clips run in parallel, ~8-12 min total
      // Standard Ken Burns: ~3-5 min total
      // ai-enhanced (AI Walkthrough): Kling AI clips (~8-15 min) + Creatomate render (~3-5 min) = up to 25 min
      // standard: Ken Burns only, Creatomate render ~3-5 min = 7.5 min
      const maxPolls = videoMode === "ai-enhanced" ? 360 : 90; // 360×5s=30min for AI Walkthrough, 90×5s=7.5min for standard

      // Stage → progress % and human-readable message
      const stageInfo: Record<string, { progress: number; message: string }> = {
        preparing:                { progress: 20, message: "Preparing your property tour..." },
        generating_voiceover:     { progress: 30, message: "Generating professional AI voiceover narration..." },
        generating_ai_clips:      { progress: 45, message: "Generating AI walkthrough clips — this takes 5-10 minutes..." },
        submitting_to_renderer:   { progress: 70, message: "Submitting to video renderer..." },
        submitting_to_shotstack:  { progress: 70, message: "Preparing your video for final render..." },
        fetching_assets:          { progress: 75, message: "Loading your assets for rendering..." },
        rendering:                { progress: 80, message: "Rendering your video..." },
        saving:                   { progress: 92, message: "Finalizing and saving your video..." },
      };

      // Poll for completion
      const pollInterval = setInterval(async () => {
        try {
          pollCount++;
          console.log(`[PropertyTours] Poll #${pollCount} for tour ${tour.id}`);
          const status = await utils.propertyTours.checkRenderStatus.fetch({ tourId: tour.id });
          console.log("[PropertyTours] Status response:", status);

          // Update progress based on processingStage
          const stage = (status as any).processingStage as string | null | undefined;
          if (stage && stageInfo[stage]) {
            const { progress, message } = stageInfo[stage];
            // For rendering, advance progress gradually with poll count
            if (stage === "rendering") {
              setGenerationProgress(Math.min(80 + Math.floor(pollCount * 0.5), 91));
            } else {
              setGenerationProgress(progress);
            }
            setGenerationStatus(message);
          } else if (status.status === "processing" && !stage) {
            // Legacy fallback: no processingStage
            const renderProgress = Math.min(30 + (pollCount * 2), 80);
            setGenerationProgress(renderProgress);
            setGenerationStatus("Rendering your video...");
          }

            if (status.status === "done" || status.status === "completed") {
            clearInterval(pollInterval);
            setGenerationProgress(100);
            setGenerationStatus("Video ready!");
            setTimeout(async () => {
              setGeneratingTourId(null);
              setGenerationProgress(0);
              setGenerationStatus("");
              // Show the video-ready modal
              if ((status as any).videoUrl) {
                setReadyVideoUrl((status as any).videoUrl);
                setReadyVideoAddress(address || "Your Property Tour");
              } else {
                // Fetch from list to get the URL
                const tours = await utils.propertyTours.list.fetch();
                const latest = tours?.find((t: any) => t.status === "completed" && t.videoUrl);
                if (latest?.videoUrl) {
                  setReadyVideoUrl(latest.videoUrl);
                  setReadyVideoAddress(latest.address || "Your Property Tour");
                }
              }
            }, 1500);
            utils.propertyTours.list.invalidate();
          } else if (status.status === "failed") {
            clearInterval(pollInterval);
            setGeneratingTourId(null);
            setGenerationProgress(0);
            setGenerationStatus("");
            const errDetail = (status as any).error;
            if (errDetail) {
              toast.error(
                <div>
                  <p className="font-semibold mb-1">Video generation failed</p>
                  <p className="text-xs font-mono break-all opacity-80">{errDetail}</p>
                  <p className="text-xs mt-1 opacity-60">Your credits have been refunded. Click the failed tour to see the full error.</p>
                </div>
              );
            } else {
              toast.error("Video generation failed. Your credits have been refunded.");
            }
            utils.propertyTours.list.invalidate();
            utils.credits.getBalance.invalidate();
          }

          // Timeout after max polls
          if (pollCount >= maxPolls) {
            clearInterval(pollInterval);
            setGeneratingTourId(null);
            setGenerationProgress(0);
            setGenerationStatus("");
            toast.error("Video generation is taking longer than expected. Check My Videos later — it may still complete.");
          }
        } catch (error) {
          clearInterval(pollInterval);
          setGeneratingTourId(null);
          setGenerationProgress(0);
          setGenerationStatus("");
          console.error("Polling error:", error);
        }
      }, 5000); // Poll every 5 seconds

      // Reset form
      setAddress("");
      setPrice("");
      setBeds("");
      setBaths("");
      setSqft("");
      setPropertyType("");
      setDescription("");
      setUploadedImageUrls([]);

      // Refresh tours list
      utils.propertyTours.list.invalidate();
    } catch (error) {
      // Reset generating state so the progress bar doesn't stay stuck
      setGeneratingTourId(null);
      setGenerationProgress(0);
      setGenerationStatus("");
      const errMsg = error instanceof Error ? error.message : "Failed to create tour";
      console.error("[PropertyTours] handleCreateTour error:", errMsg, error);
      toast.error(errMsg);
    }
  };

  // Handle tour deletion
  const handleDeleteTour = async (tourId: number) => {
    try {
      const result = await deleteTour.mutateAsync({ tourId });
      if (result.creditsRefunded) {
        toast.success("Property tour deleted and credits refunded");
      } else {
        toast.success("Property tour deleted");
      }
      utils.propertyTours.list.invalidate();
      utils.credits.getBalance.invalidate(); // Refresh credit balance
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to delete tour");
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold mb-2">Listing Slideshow</h1>
            <p className="text-muted-foreground">
              Create cinematic property tour videos with Ken Burns effects
            </p>
          </div>
          {dailyUsage && (
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 border-blue-200 dark:border-blue-800">
              <div className="p-4 text-center">
                <p className="text-xs text-muted-foreground mb-1">Daily Videos</p>
                {dailyUsage.isUnlimited ? (
                  <>
                    <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                      ∞
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">Unlimited</p>
                    <p className="text-xs text-green-600 dark:text-green-400 mt-2 font-medium">
                      Pro Plan
                    </p>
                  </>
                ) : (
                  <>
                    <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                      {dailyUsage.remaining}/{dailyUsage.limit}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">remaining today</p>
                    {dailyUsage.remaining <= 2 && dailyUsage.remaining > 0 && (
                      <p className="text-xs text-orange-600 dark:text-orange-400 mt-2 font-medium">
                        Low limit!
                      </p>
                    )}
                    {dailyUsage.remaining === 0 && (
                      <p className="text-xs text-destructive mt-2 font-medium">
                        Limit reached
                      </p>
                    )}
                  </>
                )}
              </div>
            </Card>
          )}
        </div>
      </div>

      {/* Example Videos Section */}
      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">Example Videos</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl">
          {/* Ken Burns Example */}
          <Card className="overflow-hidden">
            <div className="aspect-video bg-black">
              <video
                controls
                className="w-full h-full"
                src="https://d2xsxph8kpxj0f.cloudfront.net/310419663026756998/K9BXxKfRk2PJ2AbRYdraAT/ken-burns-example_38bbc49c.mp4"
                preload="auto"
                playsInline
              >
                Your browser does not support the video tag.
              </video>
            </div>
            <div className="p-4">
              <h3 className="font-semibold text-lg mb-1">Standard — Ken Burns</h3>
              <p className="text-sm text-muted-foreground mb-2">
                Smooth cinematic zoom and pan with crossfade transitions
              </p>
              <p className="text-xs text-muted-foreground italic">
                Note: Your profile picture and contact info will appear when branding is enabled
              </p>
            </div>
          </Card>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Create New Tour Form */}
        <Card className="p-6">
          <h2 className="text-2xl font-semibold mb-6">Create New Listing Slideshow</h2>

          {/* Image Upload */}
          <div className="mb-6">
            <Label htmlFor="images">Property Images & Videos *</Label>
            <p className="text-xs text-muted-foreground mt-1 mb-2">
              Maximum 10 photos. For best results, select 5-10 of your best photos showing key features.
            </p>
            <div className="mt-2 border-2 border-dashed border-border rounded-lg p-8 text-center">
              <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-sm text-muted-foreground mb-4">
                Drag & drop images or videos (mix photos with short clips for dynamic tours)
              </p>
              <Input
                id="images"
                type="file"
                accept="image/*,video/*"
                multiple
                onChange={handleFileSelect}
                className="hidden"
              />
              <Button
                variant="outline"
                onClick={() => document.getElementById("images")?.click()}
              >
                Select Images/Videos
              </Button>
            </div>

            {selectedFiles.length > 0 && (
              <div className="mt-4 space-y-3">
                <p className="text-sm font-medium">
                  {selectedFiles.length} files selected ({selectedFiles.filter(f => f.type.startsWith('image')).length} images, {selectedFiles.filter(f => f.type.startsWith('video')).length} videos)
                </p>
                
                {/* Preview thumbnails of selected files */}
                <div className="grid grid-cols-3 gap-2">
                  {selectedFiles.map((file, i) => (
                    <div key={i} className="relative group">
                      {file.type.startsWith('image') ? (
                        <img
                          src={URL.createObjectURL(file)}
                          alt={file.name}
                          className="w-full h-24 object-cover rounded border-2 border-dashed border-muted"
                        />
                      ) : (
                        <div className="w-full h-24 flex items-center justify-center bg-muted rounded border-2 border-dashed border-muted">
                          <Video className="h-8 w-8 text-muted-foreground" />
                        </div>
                      )}
                      <Button
                        type="button"
                        size="icon"
                        variant="destructive"
                        className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => {
                          const newFiles = selectedFiles.filter((_, index) => index !== i);
                          setSelectedFiles(newFiles);
                          toast.success("File removed from selection");
                        }}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                      <p className="text-xs text-muted-foreground mt-1 truncate">{file.name}</p>
                    </div>
                  ))}
                </div>
                
                <Button
                  onClick={handleUploadImages}
                  disabled={isUploading}
                  className="w-full"
                >
                  {isUploading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Upload className="mr-2 h-4 w-4" />
                      Upload {selectedFiles.length} File{selectedFiles.length !== 1 ? 's' : ''}
                    </>
                  )}
                </Button>
              </div>
            )}

            {uploadedImageUrls.length > 0 && (
              <div className="mt-4">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-muted-foreground">
                    {uploadedImageUrls.length} photo{uploadedImageUrls.length !== 1 ? 's' : ''} uploaded
                  </p>
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setUploadedImageUrls([]);
                      setSelectedFiles([]);
                      toast.success("All photos removed");
                    }}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Remove All
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {uploadedImageUrls.map((url, i) => (
                    <div key={i} className="space-y-2">
                      <div className="relative group">
                        <img
                          src={url}
                          alt={`Property ${i + 1}`}
                          className="w-full h-32 object-cover rounded"
                        />
                        <Button
                          type="button"
                          size="icon"
                          variant="secondary"
                          className="absolute top-1 left-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => {
                            setCropImageIndex(i);
                            setCropModalOpen(true);
                          }}
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button
                          type="button"
                          size="icon"
                          variant="destructive"
                          className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => {
                            const newUrls = uploadedImageUrls.filter((_, index) => index !== i);
                            const newFiles = selectedFiles.filter((_, index) => index !== i);
                            const newMovements = perPhotoMovements.filter((_, index) => index !== i);
                            setUploadedImageUrls(newUrls);
                            setSelectedFiles(newFiles);
                            setPerPhotoMovements(newMovements);
                            toast.success("Photo removed");
                          }}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                      <Select
                        value={perPhotoMovements[i] || "auto"}
                        onValueChange={(value) => {
                          const newMovements = [...perPhotoMovements];
                          // Fill any gaps with "auto" to avoid sparse array with nulls
                          for (let j = 0; j <= i; j++) {
                            if (!newMovements[j]) newMovements[j] = "auto";
                          }
                          newMovements[i] = value;
                          setPerPhotoMovements(newMovements);
                        }}
                      >
                        <SelectTrigger className="text-xs h-8">
                          <SelectValue placeholder="Camera Movement" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="auto">🎬 Auto (Cycle)</SelectItem>
                          <SelectItem value="zoom-in-pan-right">🔍 Zoom In + Pan Right</SelectItem>
                          <SelectItem value="zoom-out-pan-left">🔎 Zoom Out + Pan Left</SelectItem>
                          <SelectItem value="pan-right-zoom">➡️ Pan Right + Zoom</SelectItem>
                          <SelectItem value="pan-left-zoom">⬅️ Pan Left + Zoom</SelectItem>
                          <SelectItem value="dramatic-zoom">⭐ Dramatic Zoom (Hero)</SelectItem>
                          <SelectItem value="pan-up-zoom">⬆️ Pan Up + Zoom</SelectItem>
                          <SelectItem value="pan-down-zoom">⬇️ Pan Down + Zoom</SelectItem>
                          <SelectItem value="diagonal-pan-zoom">↗️ Diagonal Pan + Zoom</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Property Details */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="mlsId">MLS ID (Optional)</Label>
              <div className="flex gap-2">
                <Input
                  id="mlsId"
                  placeholder="Enter MLS ID to auto-fill property details"
                  className="flex-1"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={async () => {
                    const mlsIdInput = (document.getElementById("mlsId") as HTMLInputElement)?.value;
                    if (!mlsIdInput?.trim()) {
                      toast.error("Please enter an MLS ID first");
                      return;
                    }
                    try {
                      toast.info("Fetching property data from MLS...");
                      const data = await fetchPropertyData.mutateAsync({ mlsId: mlsIdInput });
                      
                      // Auto-populate form fields
                      setAddress(data.address || "");
                      setPrice(data.price ? `$${data.price.toLocaleString()}` : "");
                      setBeds(data.beds.toString());
                      setBaths(data.baths.toString());
                      setSqft(data.sqft.toString());
                      setPropertyType(data.propertyType);
                      setDescription(data.description);
                      
                      toast.success("Property data loaded! Please upload your own photos.");
                    } catch (error) {
                      toast.error(
                        error instanceof Error
                          ? error.message
                          : "Failed to fetch property data from MLS"
                      );
                    }
                  }}
                  disabled={fetchPropertyData.isPending}
                >
                  {fetchPropertyData.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    "Fetch Data"
                  )}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Enter MLS ID and click "Fetch Data" to auto-populate property details (address, price, beds, baths, sqft)
              </p>
            </div>

            <div>
              <Label htmlFor="address">Address *</Label>
              <Input
                id="address"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="123 Main St, City, State 12345"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="price">Price</Label>
                <Input
                  id="price"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="$500,000"
                />
              </div>
              <div>
                <Label htmlFor="propertyType">Property Type</Label>
                <Input
                  id="propertyType"
                  value={propertyType}
                  onChange={(e) => setPropertyType(e.target.value)}
                  placeholder="Single Family"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="beds">Beds</Label>
                <Input
                  id="beds"
                  type="number"
                  value={beds}
                  onChange={(e) => setBeds(e.target.value)}
                  placeholder="3"
                />
              </div>
              <div>
                <Label htmlFor="baths">Baths</Label>
                <Input
                  id="baths"
                  type="number"
                  step="0.5"
                  value={baths}
                  onChange={(e) => setBaths(e.target.value)}
                  placeholder="2.5"
                />
              </div>
              <div>
                <Label htmlFor="sqft">Sq Ft</Label>
                <Input
                  id="sqft"
                  type="number"
                  value={sqft}
                  onChange={(e) => setSqft(e.target.value)}
                  placeholder="2000"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Beautiful property with..."
                rows={3}
              />
            </div>

            {/* Agent Branding */}
            <div className="flex items-center space-x-2">
              <Checkbox
                id="includeBranding"
                checked={includeBranding}
                onCheckedChange={(checked) => setIncludeBranding(checked as boolean)}
              />
              <Label htmlFor="includeBranding" className="text-sm font-normal cursor-pointer">
                Include my branding (profile picture and contact info)
              </Label>
            </div>

            {/* Intro Video */}
            <div className="flex items-center space-x-2">
              <Checkbox
                id="includeIntroVideo"
                checked={includeIntroVideo}
                onCheckedChange={(checked) => {
                  setIncludeIntroVideo(checked as boolean);
                  if (!checked) {
                    setUseProfileAvatar(null);
                    setCustomAvatarPreview("");
                    setCustomAvatarFile(null);
                  }
                }}
              />
              <Label htmlFor="includeIntroVideo" className="text-sm font-normal cursor-pointer">
                Prepend my intro video (adds personal intro before property tour)
              </Label>
            </div>

            {/* Avatar headshot choice — shown when intro video is enabled */}
            {includeIntroVideo && (
              <div className="ml-6 mt-2 p-4 rounded-lg border bg-muted/30 space-y-3">
                <p className="text-sm font-medium">Agent Headshot for Intro</p>

                {/* Saved profile avatar option */}
                {currentUser?.avatarImageUrl && useProfileAvatar !== false && (
                  <div className="flex items-center gap-3">
                    <img
                      src={currentUser.avatarImageUrl}
                      alt="Saved profile headshot"
                      className="w-14 h-14 rounded-full object-cover border-2 border-primary"
                    />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-foreground">Your saved headshot</p>
                      <p className="text-xs text-muted-foreground">From your profile</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        size="sm"
                        variant={useProfileAvatar === true ? "default" : "outline"}
                        onClick={() => { setUseProfileAvatar(true); setCustomAvatarPreview(""); setCustomAvatarFile(null); }}
                      >
                        {useProfileAvatar === true ? <><Check className="w-3 h-3 mr-1" />Using this</> : "Use this"}
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        onClick={() => setUseProfileAvatar(false)}
                      >
                        Use different
                      </Button>
                    </div>
                  </div>
                )}

                {/* Custom upload option */}
                {(useProfileAvatar === false || !currentUser?.avatarImageUrl) && (
                  <div className="space-y-2">
                    {customAvatarPreview ? (
                      <div className="flex items-center gap-3">
                        <img
                          src={customAvatarPreview}
                          alt="Custom headshot"
                          className="w-14 h-14 rounded-full object-cover border-2 border-primary"
                        />
                        <div className="flex-1">
                          <p className="text-sm font-medium">Custom headshot ready</p>
                          <p className="text-xs text-muted-foreground">Will be used for this tour</p>
                        </div>
                        <div className="flex gap-2">
                          {currentUser?.avatarImageUrl && (
                            <Button type="button" size="sm" variant="ghost" onClick={() => setUseProfileAvatar(true)}>
                              Use saved instead
                            </Button>
                          )}
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => { setCustomAvatarPreview(""); setCustomAvatarFile(null); }}
                          >
                            <X className="w-3 h-3 mr-1" />Remove
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <label className="flex flex-col items-center justify-center w-full h-20 border-2 border-dashed rounded-lg cursor-pointer hover:bg-muted/50 transition-colors">
                        <UserCircle2 className="w-6 h-6 text-muted-foreground mb-1" />
                        <span className="text-xs text-muted-foreground">Upload your headshot</span>
                        <input
                          id="avatarHeadshotUpload"
                          name="avatarHeadshotUpload"
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            const reader = new FileReader();
                            reader.onload = (ev) => {
                              setAvatarCropImageUrl(ev.target?.result as string);
                              setShowAvatarCropModal(true);
                            };
                            reader.readAsDataURL(file);
                          }}
                        />
                      </label>
                    )}
                  </div>
                )}

                {/* Prompt to choose if no decision yet and profile avatar exists */}
                {useProfileAvatar === null && currentUser?.avatarImageUrl && (
                  <p className="text-xs text-muted-foreground">Choose to use your saved headshot or upload a different one.</p>
                )}
                {!currentUser?.avatarImageUrl && !customAvatarPreview && (
                  <p className="text-xs text-amber-600">No saved headshot found. Upload one above, or go to AI Reels to save your profile headshot.</p>
                )}
              </div>
            )}



            {/* Video Mode Selection */}
            <div className="space-y-3 p-3 rounded-lg border border-border bg-muted/20">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-semibold">Video Style</Label>
                  <p className="text-xs text-muted-foreground mt-0.5">Choose how your property tour is animated</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setVideoMode("standard")}
                  className={`p-3 rounded-lg border-2 text-left transition-all ${
                    videoMode === "standard"
                      ? "border-primary bg-primary/10"
                      : "border-border bg-background hover:border-primary/50"
                  }`}
                >
                  <div className="text-sm font-semibold mb-1">🎬 Standard</div>
                  <div className="text-xs text-muted-foreground">Smooth Ken Burns zoom &amp; pan effects</div>
                  <div className="text-xs text-green-600 font-medium mt-1">Fast · 5 credits</div>
                </button>
                <button
                  type="button"
                  onClick={() => setVideoMode("ai-enhanced")}
                  className={`p-3 rounded-lg border-2 text-left transition-all ${
                    videoMode === "ai-enhanced"
                      ? "border-primary bg-primary/10"
                      : "border-border bg-background hover:border-primary/50"
                  }`}
                >
                  <div className="text-sm font-semibold mb-1">✨ AI Walkthrough</div>
                  <div className="text-xs text-muted-foreground">Real camera movement through rooms</div>
                  <div className="text-xs text-amber-600 font-medium mt-1">~5 min · 15 credits</div>
                </button>
              </div>
              {videoMode === "ai-enhanced" && (
                <p className="text-xs text-muted-foreground bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded p-2">
                  🎥 AI Walkthrough uses Kling AI to generate real camera movement (dolly push, arc turns, crane shots) for your best 3–5 photos. Takes ~5 minutes to generate.
                </p>
              )}
            </div>
            {/* Movement Speed Preset */}
            <div className="space-y-2">
              <Label htmlFor="movementSpeed">Camera Movement Speed</Label>
              <Select value={movementSpeed} onValueChange={(value: "slow" | "fast") => setMovementSpeed(value)}>
                <SelectTrigger id="movementSpeed">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="slow">🎬 Slow & Dramatic (6-8s per photo)</SelectItem>
                  <SelectItem value="fast">⚡ Fast & Energetic (3-4s per photo)</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                {movementSpeed === "slow" 
                  ? "Cinematic, gentle movements perfect for luxury properties" 
                  : "Quick, dynamic pacing ideal for modern, energetic listings"}
              </p>
            </div>

            {/* Voiceover Options */}
            <div className="space-y-3 p-3 rounded-lg border border-border bg-muted/20">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="enableVoiceover"
                    checked={enableVoiceover}
                    onCheckedChange={(checked) => setEnableVoiceover(checked as boolean)}
                  />
                  <Label htmlFor="enableVoiceover" className="text-sm font-medium cursor-pointer">
                    AI Voiceover Narration
                  </Label>
                </div>
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                  enableVoiceover
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground"
                }`}>
                  +5 credits
                </span>
              </div>
              <p className="text-xs text-muted-foreground">
                AI generates a professional narration track from your property details. The script is auto-generated and fully editable before rendering.
              </p>
              {enableVoiceover && (
                <div className="space-y-4 pt-1">

                  {/* Narration Style */}
                  <div>
                    <Label htmlFor="voiceoverStyleGroup" className="text-xs font-medium">Narration Style</Label>
                    <div className="grid grid-cols-2 gap-2 mt-1.5">
                      {([
                        { value: "professional", label: "Professional", desc: "Authoritative & polished" },
                        { value: "warm",         label: "Warm",         desc: "Friendly & welcoming" },
                        { value: "luxury",       label: "Luxury",       desc: "Elegant & exclusive" },
                        { value: "casual",       label: "Casual",       desc: "Relaxed & conversational" },
                      ] as const).map((s) => (
                        <button
                          key={s.value}
                          type="button"
                          onClick={() => setVoiceoverStyle(s.value)}
                          className={`text-left p-2 rounded-md border text-xs transition-colors ${
                            voiceoverStyle === s.value
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-border hover:border-primary/50"
                          }`}
                        >
                          <div className="font-semibold">{s.label}</div>
                          <div className="text-muted-foreground">{s.desc}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Voice Selection with Preview */}
                  <div>
                    <Label htmlFor="voiceSelectionGroup" className="text-xs font-medium">Voice</Label>
                    <div className="space-y-1.5 mt-1.5">
                      {/* Cloned voice option — shown first if agent has one */}
                      {(personaData as any)?.elevenlabsVoiceId && (
                        <div
                          onClick={() => setVoiceId((personaData as any).elevenlabsVoiceId)}
                          className={`flex items-center justify-between p-2 rounded-md border cursor-pointer transition-colors ${
                            voiceId === (personaData as any).elevenlabsVoiceId
                              ? "border-primary bg-primary/10"
                              : "border-border hover:border-primary/40"
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <div className={`w-3 h-3 rounded-full border-2 flex-shrink-0 ${
                              voiceId === (personaData as any).elevenlabsVoiceId ? "border-primary bg-primary" : "border-muted-foreground"
                            }`} />
                            <div>
                              <span className="text-xs font-medium">{(personaData as any).elevenlabsVoiceName || "My Voice"}</span>
                              <span className="text-xs text-muted-foreground ml-1.5">Your Cloned Voice</span>
                              <span className="ml-1.5 text-[10px] bg-green-500/20 text-green-600 dark:text-green-400 px-1.5 py-0.5 rounded-full font-medium">Cloned</span>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); handleVoicePreview((personaData as any).elevenlabsVoiceId); }}
                            disabled={previewingVoiceId === (personaData as any).elevenlabsVoiceId}
                            className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-primary border border-border hover:border-primary/50 px-2 py-1 rounded transition-colors disabled:opacity-50"
                          >
                            {previewingVoiceId === (personaData as any).elevenlabsVoiceId ? (
                              <><Loader2 className="w-3 h-3 animate-spin" /> Loading...</>
                            ) : (
                              <><Play className="w-3 h-3" /> Preview</>
                            )}
                          </button>
                        </div>
                      )}
                      {([
                        { id: "21m00Tcm4TlvDq8ikWAM", name: "Rachel", desc: "Professional Female", tag: "Popular" },
                        { id: "pNInz6obpgDQGcFmaJgB", name: "Adam",   desc: "Professional Male",   tag: "" },
                        { id: "EXAVITQu4vr4xnSDxMaL", name: "Bella",  desc: "Warm Female",         tag: "" },
                        { id: "TxGEqnHWrfWFTfGW9XjX", name: "Josh",   desc: "Authoritative Male",  tag: "" },
                      ]).map((v) => (
                        <div
                          key={v.id}
                          onClick={() => setVoiceId(v.id)}
                          className={`flex items-center justify-between p-2 rounded-md border cursor-pointer transition-colors ${
                            voiceId === v.id
                              ? "border-primary bg-primary/10"
                              : "border-border hover:border-primary/40"
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <div className={`w-3 h-3 rounded-full border-2 flex-shrink-0 ${
                              voiceId === v.id ? "border-primary bg-primary" : "border-muted-foreground"
                            }`} />
                            <div>
                              <span className="text-xs font-medium">{v.name}</span>
                              <span className="text-xs text-muted-foreground ml-1.5">{v.desc}</span>
                              {v.tag && (
                                <span className="ml-1.5 text-[10px] bg-primary/20 text-primary px-1.5 py-0.5 rounded-full font-medium">{v.tag}</span>
                              )}
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); handleVoicePreview(v.id); }}
                            disabled={previewingVoiceId === v.id}
                            className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-primary border border-border hover:border-primary/50 px-2 py-1 rounded transition-colors disabled:opacity-50"
                          >
                            {previewingVoiceId === v.id ? (
                              <><Loader2 className="w-3 h-3 animate-spin" /> Loading...</>
                            ) : (
                              <><Play className="w-3 h-3" /> Preview</>
                            )}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Custom Script */}
                  <div>
                    <Label htmlFor="voiceoverScript" className="text-xs font-medium">Custom Script <span className="text-muted-foreground font-normal">(Optional)</span></Label>
                    <Textarea
                      id="voiceoverScript"
                      placeholder="Leave blank — AI will auto-generate a script in the selected style from your property details. Or paste your own narration here."
                      value={customScript}
                      onChange={(e) => setCustomScript(e.target.value)}
                      rows={4}
                      className="resize-none font-mono text-xs mt-1"
                    />
                    {customScript && (
                      <div className="flex items-center justify-between mt-1">
                        <p className="text-xs text-muted-foreground">
                          {customScript.split(/\s+/).filter(Boolean).length} words · ~{Math.ceil(customScript.split(/\s+/).filter(Boolean).length / 2.5)}s spoken
                        </p>
                        <button
                          type="button"
                          onClick={() => setCustomScript("")}
                          className="text-xs text-muted-foreground hover:text-destructive underline"
                        >
                          Clear
                        </button>
                      </div>
                    )}
                    {!customScript && (
                      <p className="text-xs text-muted-foreground mt-1">
                        Script will be generated in <strong>{voiceoverStyle}</strong> style and shown for review before video creation.
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>



            {/* Video Settings */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="template">Video Template</Label>
                <Select value={template} onValueChange={(v: any) => setTemplate(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="modern">Modern</SelectItem>
                    <SelectItem value="luxury">Luxury</SelectItem>
                    <SelectItem value="cozy">Cozy</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="duration">Video Duration</Label>
                <Select value={duration.toString()} onValueChange={(v) => setDuration(parseInt(v))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 seconds (Quick Reel)</SelectItem>
                    <SelectItem value="30">30 seconds (Standard)</SelectItem>
                    <SelectItem value="60">60 seconds (Detailed)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Aspect Ratio & Music */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="aspectRatio">Aspect Ratio</Label>
                <Select value={aspectRatio} onValueChange={(v: any) => setAspectRatio(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="16:9">16:9 (YouTube)</SelectItem>
                    <SelectItem value="9:16">9:16 (Reels/TikTok)</SelectItem>
                    <SelectItem value="1:1">1:1 (Instagram)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {/* Music Library */}
              <div className="col-span-2">
                <MusicLibrary
                  onSelectTrack={(trackId, trackUrl) => {
                    setMusicTrack(trackId);
                    setMusicTrackUrl(trackUrl);
                  }}
                  selectedTrackId={musicTrack}
                  propertyType={propertyType as 'luxury' | 'family' | 'modern' | 'commercial' | 'any' || 'any'}
                  volume={musicVolume}
                  onVolumeChange={setMusicVolume}
                  showVolumeControl={true}
                />
              </div>
            </div>

            {/* Card Template Selector */}
            {includeBranding && (
              <div className="space-y-3">
                <Label htmlFor="cardTemplate">Intro/Outro Card Style</Label>
                <Select value={cardTemplate} onValueChange={(v: any) => setCardTemplate(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="modern">
                      <div className="flex flex-col">
                        <span className="font-semibold">Modern Minimalist</span>
                        <span className="text-xs text-muted-foreground">Clean lines, simple typography</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="luxury">
                      <div className="flex flex-col">
                        <span className="font-semibold">Luxury Elegant</span>
                        <span className="text-xs text-muted-foreground">Sophisticated gradients, serif fonts</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="bold">
                      <div className="flex flex-col">
                        <span className="font-semibold">Bold & Dynamic</span>
                        <span className="text-xs text-muted-foreground">Vibrant colors, strong typography</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="classic">
                      <div className="flex flex-col">
                        <span className="font-semibold">Classic Professional</span>
                        <span className="text-xs text-muted-foreground">Traditional layout, conservative design</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="contemporary">
                      <div className="flex flex-col">
                        <span className="font-semibold">Contemporary Chic</span>
                        <span className="text-xs text-muted-foreground">Trendy design, modern aesthetics</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  Choose a style for your intro and outro cards. Each template has matching designs for a cohesive look.
                </p>
              </div>
            )}

            {/* Credit Cost Display */}
            {creditCost && balance && (
              <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Cost for this video:</span>
                  <span className="text-lg font-bold text-primary">{creditCost.totalCredits} credits</span>
                </div>
                <div className="text-xs text-muted-foreground space-y-1">
                  {creditCost.breakdown.map((item, i) => (
                    <div key={i} className="flex justify-between">
                      <span>{item.item}</span>
                      <span>{item.credits} credits</span>
                    </div>
                  ))}
                </div>
                <div className="mt-3 pt-3 border-t border-primary/20 flex items-center justify-between">
                  <span className="text-sm">Your balance:</span>
                  <span className={`font-semibold ${balance.balance < creditCost.totalCredits ? 'text-destructive' : 'text-primary'}`}>
                    {balance.balance} credits
                  </span>
                </div>
                {balance.balance < creditCost.totalCredits && (
                  <div className="mt-2 text-xs text-destructive">
                    Insufficient credits. <a href="/credits" className="underline font-medium">Purchase more credits</a>
                  </div>
                )}
              </div>
            )}

            <div className="space-y-2">
              <Button
                onClick={handleCreateTour}
                disabled={createTour.isPending || generateVideo.isPending || generatingTourId !== null || (balance && creditCost && balance.balance < creditCost.totalCredits)}
                className="w-full h-14 text-lg"
                size="lg"
              >
                {createTour.isPending || generateVideo.isPending || generatingTourId !== null ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating Video...
                  </>
                ) : (
                  <>
                    <Video className="mr-2 h-4 w-4" />
                    Create Property Tour
                  </>
                )}
              </Button>
              
              {uploadedImageUrls.length > 0 && (
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    // Reset all form fields
                    setAddress("");
                    setPrice("");
                    setBeds("");
                    setBaths("");
                    setSqft("");
                    setPropertyType("");
                    setDescription("");
                    setUploadedImageUrls([]);
                    setSelectedFiles([]);
                    setTemplate("modern");
                    setDuration(30);
                    setIncludeBranding(true);
                    setAspectRatio("16:9");
                    setMusicTrack(undefined);
                    setCardTemplate("modern");
                    setIncludeIntroVideo(false);
                    setEnableVoiceover(false);
                    setShowScriptEditor(false);
                    setGeneratedScript("");
                    setCustomScript("");
                    toast.success("Form cleared");
                  }}
                  disabled={createTour.isPending || generateVideo.isPending || generatingTourId !== null}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Cancel & Clear Form
                </Button>
              )}
            </div>

            {/* Progress Indicator */}
            {generatingTourId !== null && (
              <div className="mt-4 space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">{generationStatus}</span>
                  <span className="font-medium">{generationProgress}%</span>
                </div>
                <Progress value={generationProgress} className="h-2" />
                <div className="flex items-center justify-between">
                  <p className="text-xs text-muted-foreground">
                    Video generation may take up to 2 minutes
                  </p>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    disabled={deleteTour.isPending}
                    onClick={async () => {
                      if (confirm("Cancel video generation? Your credits will be refunded.")) {
                        if (generatingTourId) {
                          try {
                            await deleteTour.mutateAsync({ tourId: generatingTourId });
                            setGeneratingTourId(null);
                            setGenerationProgress(0);
                            setGenerationStatus("");
                            toast.success("Video generation cancelled and credits refunded");
                            utils.propertyTours.list.invalidate();
                            utils.credits.getBalance.invalidate();
                          } catch (error) {
                            toast.error("Failed to cancel video generation");
                          }
                        }
                      }
                    }}
                  >
                    {deleteTour.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Cancelling...
                      </>
                    ) : (
                      "Cancel"
                    )}
                  </Button>
                </div>
              </div>
            )}
          </div>
        </Card>

        {/* Tours Library */}
        <div>
          <h2 className="text-2xl font-semibold mb-6">Your Listing Slideshows</h2>

          {toursLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : tours && tours.length > 0 ? (
            <div className="space-y-4">
              {tours.map((tour) => (
                <Card key={tour.id} className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="w-32 h-24 bg-muted rounded flex items-center justify-center overflow-hidden relative group">
                      {tour.status === "completed" && tour.videoUrl ? (
                        <VideoThumbnail
                          src={tour.videoUrl}
                          thumbnailUrl={tour.thumbnailUrl || undefined}
                          address={tour.address}
                        />
                      ) : tour.thumbnailUrl ? (
                        <img
                          src={tour.thumbnailUrl}
                          alt={tour.address}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Video className="h-8 w-8 text-muted-foreground" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold">{tour.address}</h3>
                      {tour.price && (
                        <p className="text-sm text-muted-foreground">{tour.price}</p>
                      )}
                      <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
                        {tour.beds && <span>{tour.beds} BD</span>}
                        {tour.baths && <span>| {tour.baths} BA</span>}
                        {tour.sqft && (
                          <span>| {parseInt(tour.sqft.toString()).toLocaleString()} SQ FT</span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-3">
                        {tour.status === "completed" && tour.videoUrl ? (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              asChild
                            >
                              <a href={tour.videoUrl} target="_blank" rel="noopener noreferrer">
                                <Play className="mr-2 h-4 w-4" />
                                Preview
                              </a>
                            </Button>
                            <Button
                              size="sm"
                              asChild
                            >
                              <a href={tour.videoUrl} download>
                                <Download className="mr-2 h-4 w-4" />
                                Download
                              </a>
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-destructive hover:text-destructive"
                              onClick={async () => {
                                const isProcessingOrFailed = tour.status === "processing" || tour.status === "failed";
                                const message = isProcessingOrFailed
                                  ? "Are you sure you want to delete this video? Your credits will be refunded."
                                  : "Are you sure you want to delete this video?";
                                if (confirm(message)) {
                                  await handleDeleteTour(tour.id);
                                }
                              }}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </Button>
                          </>
                        ) : tour.status === "processing" ? (
                          <span className="text-sm text-muted-foreground flex items-center">
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Generating video...
                          </span>
                        ) : tour.status === "failed" ? (
                          <div className="flex flex-col gap-1 w-full">
                            <div className="flex items-center gap-2 flex-wrap">
                              <button
                                className="flex items-center gap-1.5 text-sm text-destructive hover:text-destructive/80 transition-colors"
                                onClick={() => setExpandedErrorTourId(expandedErrorTourId === tour.id ? null : tour.id)}
                                title="Click to see full error details"
                              >
                                <AlertCircle className="h-3.5 w-3.5 flex-shrink-0" />
                                <span className="line-clamp-1 max-w-[180px]">Generation failed</span>
                                {expandedErrorTourId === tour.id ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                              </button>
                              <Button
                                size="sm"
                                variant="outline"
                                className="h-7 px-2 text-xs"
                                onClick={async () => {
                                  try {
                                    await retryVideo.mutateAsync({ tourId: tour.id });
                                    toast.success("Retrying video generation...");
                                    utils.propertyTours.list.invalidate();
                                    setGeneratingTourId(tour.id);
                                    setGenerationProgress(5);
                                    setGenerationStatus("Retrying...");
                                  } catch (error) {
                                    toast.error(error instanceof Error ? error.message : "Failed to retry");
                                  }
                                }}
                                disabled={retryVideo.isPending}
                              >
                                {retryVideo.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3 mr-1" />}
                                Retry
                              </Button>
                            </div>
                            {expandedErrorTourId === tour.id && tour.errorMessage && (
                              <div className="mt-1 p-2 rounded bg-destructive/10 border border-destructive/20 text-xs text-destructive font-mono break-all whitespace-pre-wrap max-h-32 overflow-y-auto">
                                {tour.errorMessage}
                              </div>
                            )}
                          </div>
                        ) : null}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDeleteTour(tour.id)}
                          disabled={deleteTour.isPending}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                  </div>
                  {/* YouTube SEO Panel */}
                  <div className="px-4 pb-4">
                    <YouTubeSEOPanel
                      tourId={tour.id}
                      videoUrl={tour.videoUrl}
                      initialData={{
                        youtubeTitle: tour.youtubeTitle,
                        youtubeDescription: tour.youtubeDescription,
                        youtubeTags: tour.youtubeTags,
                        youtubeTimestamps: tour.youtubeTimestamps,
                      }}
                    />
                  </div>
                </div>
              </Card>
              ))}
            </div>
          ) : (
            <Card className="p-12 text-center">
              <Video className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">
                No property tours yet. Create your first one!
              </p>
            </Card>
          )}
        </div>
      </div>
      {/* Script Editor Dialog */}
      {showScriptEditor && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="max-w-2xl w-full p-6">
            <h3 className="text-2xl font-bold mb-4">Review Voiceover Script</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Edit the script below to personalize your property tour narration. Estimated duration: {duration} seconds.
            </p>
            <Textarea
              value={customScript}
              onChange={(e) => setCustomScript(e.target.value)}
              className="min-h-[200px] mb-4"
              placeholder="Voiceover script..."
            />
            <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
              <span>{customScript.length} characters</span>
              <span>~{Math.ceil(customScript.split(' ').length / 150 * 60)} seconds spoken</span>
            </div>

            {/* Preview Audio section */}
            <div className="mb-4 p-3 rounded-md bg-secondary/40 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Preview Narration</p>
                  <p className="text-xs text-muted-foreground">Hear the full script before committing credits to the render.</p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={previewingScript || !customScript.trim()}
                  onClick={async () => {
                    setPreviewingScript(true);
                    setScriptAudioUrl(null);
                    try {
                      const result = await previewVoice.mutateAsync({
                        voiceId,
                        sampleText: customScript.trim(),
                      });
                      setScriptAudioUrl(result.url);
                      const audio = new Audio(result.url);
                      audio.onplay = () => setScriptAudioPlaying(true);
                      audio.onended = () => setScriptAudioPlaying(false);
                      audio.onpause = () => setScriptAudioPlaying(false);
                      audio.play().catch(() => {});
                    } catch {
                      toast.error("Could not generate audio preview. Please try again.");
                    } finally {
                      setPreviewingScript(false);
                    }
                  }}
                  className="flex items-center gap-1.5 flex-shrink-0"
                >
                  {previewingScript ? (
                    <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Generating...</>
                  ) : (
                    <><Play className="w-3.5 h-3.5" /> Preview Audio</>
                  )}
                </Button>
              </div>
              {scriptAudioUrl && (
                <audio
                  key={scriptAudioUrl}
                  src={scriptAudioUrl}
                  controls
                  autoPlay
                  className="w-full mt-3 h-8"
                  style={{ height: "32px" }}
                />
              )}
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => {
                  setShowScriptEditor(false);
                  setCustomScript("");
                  setGeneratedScript("");
                  setScriptAudioUrl(null);
                }}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  setShowScriptEditor(false);
                  setScriptAudioUrl(null);
                  handleCreateTour();
                }}
                className="flex-1"
              >
                Continue with This Script
              </Button>
            </div>
          </Card>
        </div>
      )}
      
      {/* Video Ready Celebration Modal */}
      {readyVideoUrl && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-card border border-border rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-5 text-white">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <PartyPopper className="w-6 h-6" />
                  <div>
                    <p className="font-bold text-lg">Your Video is Ready!</p>
                    <p className="text-green-100 text-sm truncate max-w-[280px]">{readyVideoAddress}</p>
                  </div>
                </div>
                <button
                  onClick={() => setReadyVideoUrl(null)}
                  className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Video player */}
            <div className="bg-black aspect-video">
              <video
                src={readyVideoUrl}
                controls
                autoPlay
                className="w-full h-full"
                playsInline
              />
            </div>

            {/* Actions */}
            <div className="p-5 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <a
                  href={readyVideoUrl}
                  download
                  className="flex items-center justify-center gap-2 h-11 rounded-lg bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 transition-colors"
                >
                  <Download className="w-4 h-4" />
                  Download Video
                </a>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(readyVideoUrl!);
                    setCopiedLink(true);
                    toast.success("Video link copied!");
                    setTimeout(() => setCopiedLink(false), 2000);
                  }}
                  className="flex items-center justify-center gap-2 h-11 rounded-lg border border-border bg-muted/40 hover:bg-muted font-semibold text-sm transition-colors"
                >
                  {copiedLink ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                  {copiedLink ? "Copied!" : "Copy Link"}
                </button>
              </div>
              <button
                onClick={() => {
                  const params = new URLSearchParams({
                    topic: address ? `Property Tour: ${address}` : "Cinematic Property Tour",
                    body: description || `A stunning property tour featuring ${beds ? beds + ' bed' : ''} ${baths ? baths + ' bath' : ''} ${address || 'property'}. ${description || ''}`.trim(),
                  });
                  window.location.href = `/repurpose?${params.toString()}`;
                }}
                className="w-full flex items-center justify-center gap-2 text-sm text-amber-600 hover:text-amber-700 transition-colors py-2 font-medium"
              >
                <Repeat2 className="w-4 h-4" />
                Repurpose Property Story
              </button>
              <button
                onClick={() => setReadyVideoUrl(null)}
                className="w-full text-sm text-muted-foreground hover:text-foreground transition-colors py-2"
              >
                Close and view in library below
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Image Crop Modal */}
      {cropModalOpen && cropImageIndex !== null && (
        <ImageCropModal
          open={cropModalOpen}
          onClose={() => {
            setCropModalOpen(false);
            setCropImageIndex(null);
          }}
          imageUrl={uploadedImageUrls[cropImageIndex]}
          onCropComplete={(croppedImageUrl) => {
            const newUrls = [...uploadedImageUrls];
            newUrls[cropImageIndex] = croppedImageUrl;
            setUploadedImageUrls(newUrls);
            toast.success("Photo cropped successfully");
          }}
        />
      )}

      {/* Avatar headshot crop modal */}
      {showAvatarCropModal && avatarCropImageUrl && (
        <ImageCropModal
          open={showAvatarCropModal}
          onClose={() => {
            setShowAvatarCropModal(false);
            setAvatarCropImageUrl("");
          }}
          imageUrl={avatarCropImageUrl}
          onCropComplete={async (croppedImageUrl) => {
            setShowAvatarCropModal(false);
            setAvatarCropImageUrl("");
            // Convert base64 to File
            const response = await fetch(croppedImageUrl);
            const blob = await response.blob();
            const file = new File([blob], "avatar.png", { type: "image/png" });
            setCustomAvatarFile(file);
            setCustomAvatarPreview(croppedImageUrl);
            setUseProfileAvatar(false);
            toast.success("Headshot cropped and ready!");
            // Upload to S3 and optionally save to profile
            try {
              const formData = new FormData();
              formData.append("file", file);
              const uploadRes = await fetch("/api/upload", { method: "POST", body: formData });
              if (uploadRes.ok) {
                const { url: s3Url } = await uploadRes.json();
                setCustomAvatarPreview(s3Url);
                // Offer to save to profile
                toast.success("Headshot uploaded! Saving to your profile...");
                await updateAvatarImageMutation.mutateAsync({ avatarImageUrl: s3Url });
                toast.success("Headshot saved to your profile for future use!");
              }
            } catch {
              // Non-blocking — headshot still works for this session
            }
          }}
        />
      )}
    </div>
  );
}
